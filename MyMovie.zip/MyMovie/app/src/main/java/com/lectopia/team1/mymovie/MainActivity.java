package com.lectopia.team1.mymovie;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {
    TextView tvTitle=null;
    TextView tvDirector=null;
    TextView tvRelease=null;
    TextView tvGenre=null;
    TextView tvActor=null;
    TextView tvPlot=null;
    Button btnSearch=null;
    EditText etTitle=null;
    ImageView ivPoster=null;
    MySearchTask mySearchTask=null;
    String url=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTitle=(TextView)findViewById(R.id.tvTitle);
        tvDirector=(TextView)findViewById(R.id.tvDirector);
        tvRelease=(TextView)findViewById(R.id.tvRelease);
        tvGenre=(TextView)findViewById(R.id.tvGenre);
        tvActor=(TextView)findViewById(R.id.tvActor);
        tvPlot=(TextView)findViewById(R.id.tvPlot);
        btnSearch=(Button)findViewById(R.id.btnSearch);
        etTitle=(EditText)findViewById(R.id.etTitle);
        ivPoster=(ImageView)findViewById(R.id.ivPoster);
        url="http://www.omdbapi.com";

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etTitle.getText()!=null && !etTitle.getText().toString().isEmpty()){
                    MySearchTask mySearchTask=new MySearchTask();
                    mySearchTask.execute(url.toString()+"/?apikey=49d34a38&t="+etTitle.getText().toString());
                }else{
                    Toast.makeText(getApplicationContext(),"타이틀을 입력하세요",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    class MySearchTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setConnectTimeout(10000);
                con.setRequestMethod("GET");
                con.setDoInput(true); // 데이터 받기
                //con.setDoOutput(true); // 데이터 받고, 주는 양방향 통신 가능

                int responseCode = con.getResponseCode();
                StringBuilder sb = new StringBuilder();
                if (responseCode == HttpURLConnection.HTTP_OK) { // 200
                    BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                } else {
                    sb.append("Connection failed");
                }

                con.disconnect();
                return sb.toString();
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            try {
                JSONObject jarray = new JSONObject(result);
                String director=jarray.getString("Director");
                String release=jarray.getString("Released");
                String genre=jarray.getString("Genre");
                String actor=jarray.getString("Actors");
                String plot=jarray.getString("Plot");
                String poster=jarray.getString("Poster");
                tvDirector.setText(director);
                tvRelease.setText(release);
                tvGenre.setText(genre);
                tvActor.setText(actor);
                tvPlot.setText(plot);
                MyImageTask myImageTask=new MyImageTask();
                myImageTask.execute(poster);

            }catch(JSONException e){
                e.printStackTrace();
            }

        }

    }


    class MyImageTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            String poster;
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setDoInput(true);

                InputStream is = conn.getInputStream();
                Bitmap bm = BitmapFactory.decodeStream(is);
//                    BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
//                    Bitmap bm = BitmapFactory.decodeStream(bis);
//                    bis.close();
//                    ivPoster.setImageBitmap(bm);
                ivPoster.setImageBitmap(bm);
                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
            }
        return null;
        }
    }
}
